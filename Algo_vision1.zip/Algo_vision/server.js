const express = require('express');
const path = require('path');
const app = express();
const PORT = 3001;

// Serve static files
app.use(express.static(path.join(__dirname)));

// API endpoints
app.get('/api/topics', (req, res) => {
  // Import the topics from data.js or define them
  const TOPICS = {
    graph: {
      name: 'Graph BFS / DFS', cat: 'Graphs', icon: 'bi-diagram-3-fill',
      desc: 'Run BFS and DFS on an interactive graph and watch nodes get explored.',
      time: 'O(V + E)', space: 'O(V)', file: 'graph.cpp',
      code: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;
public:
    Graph(int V) { this->V = V; adj.resize(V); }

    void addEdge(int v, int w) {
        adj[v].push_back(w);
        adj[w].push_back(v);
    }

    void BFS(int s) {
        vector<bool> visited(V, false);
        queue<int> q;
        visited[s] = true; q.push(s);
        while (!q.empty()) {
            s = q.front(); q.pop();
            cout << s << " ";
            for (auto u : adj[s])
                if (!visited[u]) { visited[u] = true; q.push(u); }
        }
    }

    void DFSUtil(int v, vector<bool>& vis) {
        vis[v] = true; cout << v << " ";
        for (int i : adj[v]) if (!vis[i]) DFSUtil(i, vis);
    }

    void DFS(int v) {
        vector<bool> visited(V, false);
        DFSUtil(v, visited);
    }
};

int main() {
    Graph g(6);
    g.addEdge(0,1); g.addEdge(0,2);
    g.addEdge(1,3); g.addEdge(1,4);
    g.addEdge(2,4); g.addEdge(2,5);
    cout << "BFS: "; g.BFS(0);
    cout << endl << "DFS: "; g.DFS(0);
    return 0;
}`
    },
    // Add other topics similarly
    sorting: {
      name: 'Sorting Algorithms', cat: 'Arrays', icon: 'bi-bar-chart-fill',
      desc: 'Visualize various sorting algorithms.',
      time: 'Varies', space: 'O(1) to O(n)', file: 'sorting.cpp',
      code: '// Sorting code here'
    },
    linkedlist: {
      name: 'Linked List', cat: 'Linear DS', icon: 'bi-link-45deg',
      desc: 'Operations on linked lists.',
      time: 'O(1) to O(n)', space: 'O(n)', file: 'linkedlist.cpp',
      code: '// Linked list code here'
    },
    stackqueue: {
      name: 'Stack & Queue', cat: 'Linear DS', icon: 'bi-layers-fill',
      desc: 'Stack and queue operations.',
      time: 'O(1)', space: 'O(n)', file: 'stack_queue.cpp',
      code: '// Stack queue code here'
    },
    bst: {
      name: 'Binary Search Tree', cat: 'Trees', icon: 'bi-diagram-2-fill',
      desc: 'BST operations.',
      time: 'O(log n)', space: 'O(n)', file: 'bst.cpp',
      code: '// BST code here'
    }
  };
  res.json(TOPICS);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});