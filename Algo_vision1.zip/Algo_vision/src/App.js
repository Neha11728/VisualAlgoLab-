import React, { useState, useEffect } from 'react';
import './App.css';

const TOPICS = {
  graph: {
    name: 'Graph BFS / DFS', cat: 'Graphs', icon: 'bi-diagram-3-fill',
    desc: 'Run BFS and DFS on an interactive graph and watch nodes get explored.',
    time: 'O(V + E)', space: 'O(V)', file: 'graph.cpp',
    code: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;
public:
    Graph(int V) { this->V = V; adj.resize(V); }

    void addEdge(int v, int w) {
        adj[v].push_back(w);
        adj[w].push_back(v);
    }

    void BFS(int s) {
        vector<bool> visited(V, false);
        queue<int> q;
        visited[s] = true; q.push(s);
        while (!q.empty()) {
            s = q.front(); q.pop();
            cout << s << " ";
            for (auto u : adj[s])
                if (!visited[u]) { visited[u] = true; q.push(u); }
        }
    }

    void DFSUtil(int v, vector<bool>& vis) {
        vis[v] = true; cout << v << " ";
        for (int i : adj[v]) if (!vis[i]) DFSUtil(i, vis);
    }

    void DFS(int v) {
        vector<bool> visited(V, false);
        DFSUtil(v, visited);
    }
};

int main() {
    Graph g(6);
    g.addEdge(0,1); g.addEdge(0,2);
    g.addEdge(1,3); g.addEdge(1,4);
    g.addEdge(2,4); g.addEdge(2,5);
    cout << "BFS: "; g.BFS(0);
    cout << "\\nDFS: "; g.DFS(0);
    return 0;
}`
  },
  sorting: {
    name: 'Sorting Algorithms', cat: 'Arrays', icon: 'bi-bar-chart-fill',
    desc: 'Visualize Bubble Sort step-by-step on an animated bar chart.',
    time: 'O(n²)', space: 'O(1)', file: 'sorting.cpp',
    code: `#include <iostream>
#include <vector>
using namespace std;

void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
}

int main() {
    vector<int> arr = {64, 34, 25, 12, 22, 11, 90};
    bubbleSort(arr);
    for (int x : arr) cout << x << " ";
    return 0;
}`
  },
  linkedlist: {
    name: 'Linked List', cat: 'Linear DS', icon: 'bi-link-45deg',
    desc: 'A linear structure where elements are linked using pointers.',
    time: 'O(n) Search', space: 'O(n)', file: 'linkedlist.cpp',
    code: `#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

class LinkedList {
    Node* head;
public:
    LinkedList() : head(nullptr) {}

    void append(int val) {
        Node* n = new Node(val);
        if (!head) { head = n; return; }
        Node* t = head;
        while (t->next) t = t->next;
        t->next = n;
    }

    void remove(int key) {
        Node *t = head, *prev = nullptr;
        if (t && t->data == key) { head = t->next; delete t; return; }
        while (t && t->data != key) { prev = t; t = t->next; }
        if (!t) return;
        prev->next = t->next; delete t;
    }

    void display() {
        Node* t = head;
        while (t) { cout << t->data << " -> "; t = t->next; }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    list.append(10); list.append(20); list.append(30);
    list.display();
    return 0;
}`
  },
  stackqueue: {
    name: 'Stack & Queue', cat: 'Linear DS', icon: 'bi-layers-fill',
    desc: 'LIFO (Stack) vs FIFO (Queue) using C++ STL containers.',
    time: 'O(1) Push/Pop', space: 'O(n)', file: 'stack_queue.cpp',
    code: `#include <iostream>
#include <stack>
#include <queue>
using namespace std;

int main() {
    // Stack (LIFO)
    stack<int> s;
    s.push(10); s.push(20); s.push(30);
    cout << "Stack top: " << s.top() << "\\n";
    while (!s.empty()) { cout << s.top() << " "; s.pop(); }
    cout << "\\n\\n";

    // Queue (FIFO)
    queue<int> q;
    q.push(10); q.push(20); q.push(30);
    cout << "Queue front: " << q.front() << "\\n";
    while (!q.empty()) { cout << q.front() << " "; q.pop(); }
    cout << "\\n";
    return 0;
}`
  },
  bst: {
    name: 'Binary Search Tree', cat: 'Trees', icon: 'bi-diagram-2-fill',
    desc: 'Left subtree keys are smaller; right subtree keys are larger.',
    time: 'O(log n) Avg', space: 'O(n)', file: 'bst.cpp',
    code: `#include <iostream>
using namespace std;

struct Node {
    int key;
    Node *left, *right;
    Node(int k) : key(k), left(nullptr), right(nullptr) {}
};

class BST {
    Node* root;
    Node* insert(Node* node, int key) {
        if (!node) return new Node(key);
        if (key < node->key) node->left  = insert(node->left,  key);
        else if (key > node->key) node->right = insert(node->right, key);
        return node;
    }
    void inorder(Node* r) {
        if (!r) return;
        inorder(r->left); cout << r->key << " "; inorder(r->right);
    }
public:
    BST() : root(nullptr) {}
    void insert(int k) { root = insert(root, k); }
    void inorder()     { inorder(root); cout << "\\n"; }
};

int main() {
    BST tree;
    for (int v : {50, 30, 70, 20, 40, 60, 80}) tree.insert(v);
    cout << "Inorder: "; tree.inorder();
    return 0;
}`
  }
};

function App() {
  const [currentTopic, setCurrentTopic] = useState('graph');
  const [copied, setCopied] = useState(false);

  const topic = TOPICS[currentTopic];

  const handleSetTopic = (id) => {
    setCurrentTopic(id);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(topic.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    // Load highlight.js
    if (window.hljs) {
      window.hljs.highlightAll();
    }
  }, [currentTopic]);

  return (
    <div id="app">
      {/* SIDEBAR */}
      <div id="sidebar">
        <div className="sidebar-header">
          <div className="brand-icon"><i className="bi bi-compass"></i></div>
          <span className="brand-name">DSA Explorer</span>
        </div>
        <div className="sidebar-body">
          <div className="sidebar-section-title mb-2">Algorithms</div>
          <button className="topic-btn" onClick={() => handleSetTopic('sorting')}>
            <span className="topic-title"><i className="bi bi-bar-chart-fill"></i> Sorting Algorithms</span>
            <span className="topic-category">Arrays</span>
          </button>
          <button className="topic-btn" onClick={() => handleSetTopic('graph')}>
            <span className="topic-title"><i className="bi bi-diagram-3-fill"></i> Graph BFS / DFS</span>
            <span className="topic-category">Graphs</span>
          </button>
          <div className="sidebar-section-title mt-4 mb-2">Data Structures</div>
          <button className="topic-btn" onClick={() => handleSetTopic('linkedlist')}>
            <span className="topic-title"><i className="bi bi-link-45deg"></i> Linked List</span>
            <span className="topic-category">Linear DS</span>
          </button>
          <button className="topic-btn" onClick={() => handleSetTopic('stackqueue')}>
            <span className="topic-title"><i className="bi bi-layers-fill"></i> Stack &amp; Queue</span>
            <span className="topic-category">Linear DS</span>
          </button>
          <button className="topic-btn" onClick={() => handleSetTopic('bst')}>
            <span className="topic-title"><i className="bi bi-diagram-2-fill"></i> Binary Search Tree</span>
            <span className="topic-category">Trees</span>
          </button>
        </div>
        <div className="quick-ref">
          <div className="quick-ref-title"><i className="bi bi-database-fill"></i> Quick Ref</div>
          <div className="quick-ref-grid">
            <span>int: 4 bytes</span><span>char: 1 byte</span>
            <span>float: 4 bytes</span><span>double: 8 bytes</span>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div id="main">
        <div id="topbar">
          <span className="badge-tag badge-cpp">C++ 17</span>
          <span className="badge-tag badge-stl">STL Standard</span>
        </div>
        <div id="content">
          {/* Topic Header */}
          <div id="topic-header">
            <div className="d-flex align-items-center gap-3">
              <div className="topic-icon-box" id="topic-icon"><i className={`bi ${topic.icon}`}></i></div>
              <div>
                <div>
                  <span className="topic-title-main" id="topic-name">{topic.name}</span>
                  <span className="topic-cat-badge" id="topic-cat">{topic.cat}</span>
                </div>
                <div className="topic-desc" id="topic-desc">{topic.desc}</div>
              </div>
            </div>
            <div className="d-flex gap-2">
              <div className="complexity-box">
                <div className="label"><i className="bi bi-lightning-fill text-warning"></i> Time</div>
                <div className="value" id="time-complexity">{topic.time}</div>
              </div>
              <div className="complexity-box">
                <div className="label"><i className="bi bi-database-fill text-info"></i> Space</div>
                <div className="value" id="space-complexity">{topic.space}</div>
              </div>
            </div>
          </div>

          {/* Work Area */}
          <div id="work-area">
            <div className="panel">
              <div className="panel-label">
                <div className="pulse-dot"></div>
                Interactive Visualizer
              </div>
              <div className="panel-inner" id="visualizer-container">
                {/* Placeholder for visualizer */}
                <p>Visualizer for {topic.name}</p>
              </div>
            </div>
            <div className="panel">
              <div className="panel-label">
                <i className="bi bi-code-slash text-secondary"></i>
                Implementation
              </div>
              <div id="code-panel">
                <div className="code-header">
                  <div className="d-flex align-items-center">
                    <div className="mac-dots">
                      <div className="mac-dot mac-red"></div>
                      <div className="mac-dot mac-yellow"></div>
                      <div className="mac-dot mac-green"></div>
                    </div>
                    <span className="filename" id="code-filename">{topic.file}</span>
                  </div>
                  <button id="copy-btn" title="Copy code" onClick={copyCode}>
                    <i className={`bi ${copied ? 'bi-clipboard-check text-success' : 'bi-clipboard'}`} id="copy-icon"></i>
                  </button>
                </div>
                <div className="code-body">
                  <pre><code className="language-cpp" id="code-display">{topic.code}</code></pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;