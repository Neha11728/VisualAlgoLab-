const TOPICS = {
  graph: {
    name: 'Graph BFS / DFS', cat: 'Graphs', icon: 'bi-diagram-3-fill',
    desc: 'Run BFS and DFS on an interactive graph and watch nodes get explored.',
    time: 'O(V + E)', space: 'O(V)', file: 'graph.cpp',
    code: `#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;
public:
    Graph(int V) { this->V = V; adj.resize(V); }

    void addEdge(int v, int w) {
        adj[v].push_back(w);
        adj[w].push_back(v);
    }

    void BFS(int s) {
        vector<bool> visited(V, false);
        queue<int> q;
        visited[s] = true; q.push(s);
        while (!q.empty()) {
            s = q.front(); q.pop();
            cout << s << " ";
            for (auto u : adj[s])
                if (!visited[u]) { visited[u] = true; q.push(u); }
        }
    }

    void DFSUtil(int v, vector<bool>& vis) {
        vis[v] = true; cout << v << " ";
        for (int i : adj[v]) if (!vis[i]) DFSUtil(i, vis);
    }

    void DFS(int v) {
        vector<bool> visited(V, false);
        DFSUtil(v, visited);
    }
};

int main() {
    Graph g(6);
    g.addEdge(0,1); g.addEdge(0,2);
    g.addEdge(1,3); g.addEdge(1,4);
    g.addEdge(2,4); g.addEdge(2,5);
    cout << "BFS: "; g.BFS(0);
    cout << "\\nDFS: "; g.DFS(0);
    return 0;
}`
  },

  sorting: {
    name: 'Sorting Algorithms', cat: 'Arrays', icon: 'bi-bar-chart-fill',
    desc: 'Visualize Bubble Sort step-by-step on an animated bar chart.',
    time: 'O(n²)', space: 'O(1)', file: 'sorting.cpp',
    code: `#include <iostream>
#include <vector>
using namespace std;

void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
}

int main() {
    vector<int> arr = {64, 34, 25, 12, 22, 11, 90};
    bubbleSort(arr);
    for (int x : arr) cout << x << " ";
    return 0;
}`
  },

  linkedlist: {
    name: 'Linked List', cat: 'Linear DS', icon: 'bi-link-45deg',
    desc: 'A linear structure where elements are linked using pointers.',
    time: 'O(n) Search', space: 'O(n)', file: 'linkedlist.cpp',
    code: `#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

class LinkedList {
    Node* head;
public:
    LinkedList() : head(nullptr) {}

    void append(int val) {
        Node* n = new Node(val);
        if (!head) { head = n; return; }
        Node* t = head;
        while (t->next) t = t->next;
        t->next = n;
    }

    void remove(int key) {
        Node *t = head, *prev = nullptr;
        if (t && t->data == key) { head = t->next; delete t; return; }
        while (t && t->data != key) { prev = t; t = t->next; }
        if (!t) return;
        prev->next = t->next; delete t;
    }

    void display() {
        Node* t = head;
        while (t) { cout << t->data << " -> "; t = t->next; }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    list.append(10); list.append(20); list.append(30);
    list.display();
    return 0;
}`
  },

  stackqueue: {
    name: 'Stack & Queue', cat: 'Linear DS', icon: 'bi-layers-fill',
    desc: 'LIFO (Stack) vs FIFO (Queue) using C++ STL containers.',
    time: 'O(1) Push/Pop', space: 'O(n)', file: 'stack_queue.cpp',
    code: `#include <iostream>
#include <stack>
#include <queue>
using namespace std;

int main() {
    // Stack (LIFO)
    stack<int> s;
    s.push(10); s.push(20); s.push(30);
    cout << "Stack top: " << s.top() << "\\n";
    while (!s.empty()) { cout << s.top() << " "; s.pop(); }
    cout << "\\n\\n";

    // Queue (FIFO)
    queue<int> q;
    q.push(10); q.push(20); q.push(30);
    cout << "Queue front: " << q.front() << "\\n";
    while (!q.empty()) { cout << q.front() << " "; q.pop(); }
    cout << "\\n";
    return 0;
}`
  },

  bst: {
    name: 'Binary Search Tree', cat: 'Trees', icon: 'bi-diagram-2-fill',
    desc: 'Left subtree keys are smaller; right subtree keys are larger.',
    time: 'O(log n) Avg', space: 'O(n)', file: 'bst.cpp',
    code: `#include <iostream>
using namespace std;

struct Node {
    int key;
    Node *left, *right;
    Node(int k) : key(k), left(nullptr), right(nullptr) {}
};

class BST {
    Node* root;
    Node* insert(Node* node, int key) {
        if (!node) return new Node(key);
        if (key < node->key) node->left  = insert(node->left,  key);
        else if (key > node->key) node->right = insert(node->right, key);
        return node;
    }
    void inorder(Node* r) {
        if (!r) return;
        inorder(r->left); cout << r->key << " "; inorder(r->right);
    }
public:
    BST() : root(nullptr) {}
    void insert(int k) { root = insert(root, k); }
    void inorder()     { inorder(root); cout << "\\n"; }
};

int main() {
    BST tree;
    for (int v : {50, 30, 70, 20, 40, 60, 80}) tree.insert(v);
    cout << "Inorder: "; tree.inorder();
    return 0;
}`
  }
};
