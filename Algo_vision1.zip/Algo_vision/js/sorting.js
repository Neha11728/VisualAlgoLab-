const SORT_INIT = [64, 34, 25, 12, 22, 11, 90];
let sortArr = [...SORT_INIT], comparing = [], sortedIdx = [];

function buildSortingHTML() {
  sortArr = [...SORT_INIT]; comparing = []; sortedIdx = [];
  return `
  <div class="viz-controls">
    <button class="btn btn-primary-viz" onclick="runBubbleSort()"><i class="bi bi-play-fill"></i> Start Bubble Sort</button>
    <button class="btn btn-reset" onclick="resetSort()"><i class="bi bi-arrow-counterclockwise"></i> Reset</button>
  </div>
  <div id="sorting-bars"></div>`;
}

function drawBars() {
  const el = document.getElementById('sorting-bars');
  if (!el) return;
  const max = Math.max(...SORT_INIT);
  el.innerHTML = sortArr.map((val, i) => {
    const h   = Math.round((val / max) * 160) + 30;
    const cls = comparing.includes(i) ? 'comparing' : sortedIdx.includes(i) ? 'sorted' : '';
    return `<div class="sort-bar ${cls}" style="height:${h}px">${val}</div>`;
  }).join('');
}

function resetSort() {
  stopAll();
  setTimeout(() => { sortArr = [...SORT_INIT]; comparing = []; sortedIdx = []; drawBars(); }, 60);
}

async function runBubbleSort() {
  if (window._running) return;
  resetSort(); await sleep(80);
  window._running = true;
  const arr = [...SORT_INIT], n = arr.length, done = [];
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (window._aborted) return;
      comparing = [j, j+1]; sortArr = [...arr]; drawBars(); await sleep(420);
      if (arr[j] > arr[j+1]) {
        [arr[j], arr[j+1]] = [arr[j+1], arr[j]];
        sortArr = [...arr]; drawBars(); await sleep(420);
      }
    }
    done.push(n - 1 - i); sortedIdx = [...done]; drawBars();
  }
  done.push(0); sortedIdx = [...done]; comparing = []; drawBars();
  window._running = false;
}
